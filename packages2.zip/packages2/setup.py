from setuptools import setup, find_packages

setup(
    name="keypoints",
    version="1.0",
    author="Liu Zi Li",
    author_email="zili.liu@hotmail.com",
    packages=find_packages(),
)